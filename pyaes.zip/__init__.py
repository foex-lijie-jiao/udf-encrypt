VERSION = [1, 0, 0]
from .pyaes import new
