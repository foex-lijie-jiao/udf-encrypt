VERSION = [1, 0, 0]
from .AESCipher import AESCipher
