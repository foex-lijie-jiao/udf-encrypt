VERSION = [1, 0, 0]
from cipher.ecbcipher import ecb
