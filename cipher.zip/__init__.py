VERSION = [1, 0, 0]
from ecbcipher import ecb
