VERSION = [1, 0, 0]
from .cipher import ecb
